﻿namespace ProductCatalog.API.Controllers
{
    using AutoMapper;
    using DataAccess;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using ProductCatalogGateway;
    using ProductCatalogGateway.Models;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    [ApiController]
    public class ProductCatalogController : ControllerBase
    {
        private readonly IRepositoryWrapper _repositoryWrapper;
        private readonly IMapper _mapper;
        private readonly ILogger _loggerFactory;

        public ProductCatalogController(IRepositoryWrapper repositoryWrapper, IMapper mapper,
            ILogger<ProductCatalogController> loggerFactory)
        {
            _repositoryWrapper = repositoryWrapper;
            _loggerFactory = loggerFactory;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            var products = await _repositoryWrapper.Product.FindAll().ConfigureAwait(false);
            var lstproducts = _mapper.Map<List<ProductsModel>>(products);
            return Ok(lstproducts);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct([FromRoute] int id)
        {
            var product = await _repositoryWrapper.Product.FindByCondition(x => x.ProductId == id).ConfigureAwait(false);
            var prod = _mapper.Map<ProductsModel>(product);

            if (prod != null)
            {
                return Ok(prod);
            }

            return NotFound();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct([FromRoute] int id, [FromBody] ProductsModel product)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != product.ProductId)
            {
                return BadRequest();
            }

            var prod = _mapper.Map<Product>(product);

            await _repositoryWrapper.Product.Update(prod).ConfigureAwait(false);

            return NoContent();
        }

        [HttpPost]
        public async Task<IActionResult> InsertProduct([FromBody] ProductsModel product)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var prod = _mapper.Map<Product>(product);

            await _repositoryWrapper.Product.Create(prod).ConfigureAwait(false);
            return CreatedAtAction("GetProduct", new { id = product.ProductId }, product);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct([FromRoute] int id)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var product = await _repositoryWrapper.Product.FindByCondition(x => x.ProductId == id).ConfigureAwait(false);

            if (product == null)
            {
                return NotFound();
            }

            _repositoryWrapper.Product.Delete(product);
            await _repositoryWrapper.Product.Save();

            return Ok(product);

        }
    }
}