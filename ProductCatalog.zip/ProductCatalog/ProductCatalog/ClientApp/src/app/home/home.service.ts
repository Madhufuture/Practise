import { Injectable } from '@angular/core';
import { HttpClient,  } from "@angular/common/http";
import { Observable } from "rxjs";


@Injectable()
export class HomeService {
  apiUrl: string = "http://localhost:5000/api/";
  //options: RequestOptions;

  constructor(private http: HttpClient) {
    //this.options = new RequestOptions({ headers: this.headers });
  }

  getAllProducts() {
    return this.http.get(this.apiUrl + "productcatalog");
  }

  insertProduct(data: any) {
    let body = JSON.stringify(data);

    return this.http.post(this.apiUrl + "productcatalog", body);

  }
}
