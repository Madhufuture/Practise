namespace ProductCatalog.API.Tests
{
    using AutoMapper;
    using Controllers;
    using DataAccess;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Moq;
    using ProductCatalogGateway;
    using ProductCatalogGateway.Models;
    using System;
    using System.Collections.Generic;
    using System.Text;
    using Xunit;

    public class ProductCatalogControllerTest
    {
        private Mock<IRepositoryWrapper> repositoryWrapperMock;

        private static Product CreateProductMockResponse(out ProductsModel responseModelMock)
        {
            var responseMock = Mock.Of<Product>(x => x.ProductId == 1
                                                     && x.Image == Encoding.ASCII.GetBytes("VGVzdCBWQWx1ZQ==")
                                                     && x.LastUpdated ==
                                                     Convert.ToDateTime("2018-11-03 18:15:54.1840000")
                                                     && x.ProductPrice == 11 && x.ProductName == "Test"
            );

            responseModelMock = Mock.Of<ProductsModel>(x => x.ProductId == 1
                                                            && x.Image ==
                                                            Encoding.ASCII.GetBytes("VGVzdCBWQWx1ZQ==")
                                                            && x.LastUpdated ==
                                                            Convert.ToDateTime("2018-11-03 18:15:54.1840000")
                                                            && x.ProductPrice == 11 && x.ProductName == "Test");
            return responseMock;
        }

        [Fact]
        public void ProductCatalog_Controller_GetAllProducts_ValidResponseTest()
        {
            var responseMock = CreateProductMockResponse(out var responseModelMock);

            var lstresponseMock = new List<Product> { responseMock };
            repositoryWrapperMock = new Mock<IRepositoryWrapper>();
            repositoryWrapperMock.Setup(repo => repo.Product.FindAll()).ReturnsAsync(lstresponseMock);

            var mapperMock = new Mock<IMapper>();
            mapperMock.Setup(m => m.Map<List<ProductsModel>>(It.IsAny<List<Product>>()))
                .Returns(new List<ProductsModel> { responseModelMock });

            var loggerMock = Mock.Of<ILogger<ProductCatalogController>>();

            var controller = new ProductCatalogController(repositoryWrapperMock.Object, mapperMock.Object, loggerMock);
            var result = controller.GetAllProducts().Result as OkObjectResult;

            Assert.NotNull(result);
            var items = Assert.IsType<List<ProductsModel>>(result.Value);
            Assert.True(items.Count == 1);
        }


    }
}