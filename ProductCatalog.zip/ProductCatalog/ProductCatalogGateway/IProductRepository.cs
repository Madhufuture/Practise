﻿namespace ProductCatalogGateway
{
    using ProductCatalog.DataAccess;

    public interface IProductRepository: IRepositoryBase<Product>
    {

    }
}