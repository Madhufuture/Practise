﻿namespace ProductCatalogGateway.Models
{
    using System;
    using System.Collections.Generic;

    public class ProductsModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductPrice { get; set; }
        public DateTime LastUpdated { get; set; }
        public byte[] Image { get; set; }

    }
}