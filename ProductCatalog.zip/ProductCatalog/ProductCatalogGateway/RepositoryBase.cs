﻿namespace ProductCatalogGateway
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using Microsoft.EntityFrameworkCore;
    using ProductCatalog.DataAccess;

    public abstract class RepositoryBase<T> : IRepositoryBase<T> where T : class
    {
        protected RepositoryBase(ProductCatalogContext context)
        {
            ProductCatalogContext = context;
        }

        public ProductCatalogContext ProductCatalogContext { get; set; }

        public async Task<IEnumerable<T>> FindAll()
        {
            var query = ProductCatalogContext.Set<T>().AsQueryable();
            foreach (var property in ProductCatalogContext.Model.FindEntityType(typeof(T)).GetNavigations())
                query = query.Include(property.Name);

            return await query.ToListAsync();
        }

        public async Task<T> FindByCondition(Expression<Func<T, bool>> expression)
        {
            var query = ProductCatalogContext.Set<T>().AsQueryable();

            foreach (var property in ProductCatalogContext.Model.FindEntityType(typeof(T)).GetNavigations())
                query = query.Include(property.Name);

            return await query.SingleOrDefaultAsync(expression);
        }

        public async Task Create(T entity)
        {
            ProductCatalogContext.Set<T>().Add(entity);
            await Save();
        }

        public async Task Update(T entity)
        {
            try
            {
                ProductCatalogContext.Set<T>().Attach(entity);
                var entry = ProductCatalogContext.Entry(entity);
                entry.State = EntityState.Modified;
                await Save();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void Delete(T entity)
        {
            ProductCatalogContext.Set<T>().Remove(entity);
        }

        public async Task Save()
        {
            await ProductCatalogContext.SaveChangesAsync();
        }
    }
}